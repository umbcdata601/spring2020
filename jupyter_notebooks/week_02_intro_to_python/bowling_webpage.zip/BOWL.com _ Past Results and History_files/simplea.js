﻿// Sweet Alert Plugin
!function (e, t, n) { "use strict"; !function o(e, t, n) { function a(s, l) { if (!t[s]) { if (!e[s]) { var i = "function" == typeof require && require; if (!l && i) return i(s, !0); if (r) return r(s, !0); var u = new Error("Cannot find module '" + s + "'"); throw u.code = "MODULE_NOT_FOUND", u } var c = t[s] = { exports: {} }; e[s][0].call(c.exports, function (t) { var n = e[s][1][t]; return a(n ? n : t) }, c, c.exports, o, e, t, n) } return t[s].exports } for (var r = "function" == typeof require && require, s = 0; s < n.length; s++) a(n[s]); return a }({ 1: [function (o, a, r) { var s = function (e) { return e && e.__esModule ? e : { "default": e } }; Object.defineProperty(r, "__esModule", { value: !0 }); var l, i, u, c, d = o("./modules/handle-dom"), f = o("./modules/utils"), p = o("./modules/handle-swal-dom"), m = o("./modules/handle-click"), v = o("./modules/handle-key"), y = s(v), h = o("./modules/default-params"), b = s(h), g = o("./modules/set-params"), w = s(g); r["default"] = u = c = function () { function o(e) { var t = a; return t[e] === n ? b["default"][e] : t[e] } var a = arguments[0]; if (d.addClass(t.body, "stop-scrolling"), p.resetInput(), a === n) return f.logStr("SweetAlert expects at least 1 attribute!"), !1; var r = f.extend({}, b["default"]); switch (typeof a) { case "string": r.title = a, r.text = arguments[1] || "", r.type = arguments[2] || ""; break; case "object": if (a.title === n) return f.logStr('Missing "title" argument!'), !1; r.title = a.title; for (var s in b["default"]) r[s] = o(s); r.confirmButtonText = r.showCancelButton ? "Confirm" : b["default"].confirmButtonText, r.confirmButtonText = o("confirmButtonText"), r.doneFunction = arguments[1] || null; break; default: return f.logStr('Unexpected type of argument! Expected "string" or "object", got ' + typeof a), !1 } w["default"](r), p.fixVerticalPosition(), p.openModal(arguments[1]); for (var u = p.getModal(), v = u.querySelectorAll("button"), h = ["onclick", "onmouseover", "onmouseout", "onmousedown", "onmouseup", "onfocus"], g = function (e) { return m.handleButton(e, r, u) }, C = 0; C < v.length; C++) for (var S = 0; S < h.length; S++) { var x = h[S]; v[C][x] = g } p.getOverlay().onclick = g, l = e.onkeydown; var k = function (e) { return y["default"](e, r, u) }; e.onkeydown = k, e.onfocus = function () { setTimeout(function () { i !== n && (i.focus(), i = n) }, 0) }, c.enableButtons() }, u.setDefaults = c.setDefaults = function (e) { if (!e) throw new Error("userParams is required"); if ("object" != typeof e) throw new Error("userParams has to be a object"); f.extend(b["default"], e) }, u.close = c.close = function () { var o = p.getModal(); d.fadeOut(p.getOverlay(), 5), d.fadeOut(o, 5), d.removeClass(o, "showSweetAlert"), d.addClass(o, "hideSweetAlert"), d.removeClass(o, "visible"); var a = o.querySelector(".sa-icon.sa-success"); d.removeClass(a, "animate"), d.removeClass(a.querySelector(".sa-tip"), "animateSuccessTip"), d.removeClass(a.querySelector(".sa-long"), "animateSuccessLong"); var r = o.querySelector(".sa-icon.sa-error"); d.removeClass(r, "animateErrorIcon"), d.removeClass(r.querySelector(".sa-x-mark"), "animateXMark"); var s = o.querySelector(".sa-icon.sa-warning"); return d.removeClass(s, "pulseWarning"), d.removeClass(s.querySelector(".sa-body"), "pulseWarningIns"), d.removeClass(s.querySelector(".sa-dot"), "pulseWarningIns"), setTimeout(function () { var e = o.getAttribute("data-custom-class"); d.removeClass(o, e) }, 300), d.removeClass(t.body, "stop-scrolling"), e.onkeydown = l, e.previousActiveElement && e.previousActiveElement.focus(), i = n, clearTimeout(o.timeout), !0 }, u.showInputError = c.showInputError = function (e) { var t = p.getModal(), n = t.querySelector(".sa-input-error"); d.addClass(n, "show"); var o = t.querySelector(".sa-error-container"); d.addClass(o, "show"), o.querySelector("p").innerHTML = e, setTimeout(function () { u.enableButtons() }, 1), t.querySelector("input").focus() }, u.resetInputError = c.resetInputError = function (e) { if (e && 13 === e.keyCode) return !1; var t = p.getModal(), n = t.querySelector(".sa-input-error"); d.removeClass(n, "show"); var o = t.querySelector(".sa-error-container"); d.removeClass(o, "show") }, u.disableButtons = c.disableButtons = function () { var e = p.getModal(), t = e.querySelector("button.confirm"), n = e.querySelector("button.cancel"); t.disabled = !0, n.disabled = !0 }, u.enableButtons = c.enableButtons = function () { var e = p.getModal(), t = e.querySelector("button.confirm"), n = e.querySelector("button.cancel"); t.disabled = !1, n.disabled = !1 }, "undefined" != typeof e ? e.sweetAlert = e.swal = u : f.logStr("SweetAlert is a frontend module!"), a.exports = r["default"] }, { "./modules/default-params": 2, "./modules/handle-click": 3, "./modules/handle-dom": 4, "./modules/handle-key": 5, "./modules/handle-swal-dom": 6, "./modules/set-params": 8, "./modules/utils": 9 }], 2: [function (e, t, n) { Object.defineProperty(n, "__esModule", { value: !0 }); var o = { title: "", text: "", type: null, allowOutsideClick: !1, showConfirmButton: !0, showCancelButton: !1, closeOnConfirm: !0, closeOnCancel: !0, confirmButtonText: "OK", confirmButtonColor: "#8CD4F5", cancelButtonText: "Cancel", imageUrl: null, imageSize: null, timer: null, customClass: "", html: !1, animation: !0, allowEscapeKey: !0, inputType: "text", inputPlaceholder: "", inputValue: "", showLoaderOnConfirm: !1 }; n["default"] = o, t.exports = n["default"] }, {}], 3: [function (t, n, o) { Object.defineProperty(o, "__esModule", { value: !0 }); var a = t("./utils"), r = (t("./handle-swal-dom"), t("./handle-dom")), s = function (t, n, o) { function s(e) { m && n.confirmButtonColor && (p.style.backgroundColor = e) } var u, c, d, f = t || e.event, p = f.target || f.srcElement, m = -1 !== p.className.indexOf("confirm"), v = -1 !== p.className.indexOf("sweet-overlay"), y = r.hasClass(o, "visible"), h = n.doneFunction && "true" === o.getAttribute("data-has-done-function"); switch (m && n.confirmButtonColor && (u = n.confirmButtonColor, c = a.colorLuminance(u, -.04), d = a.colorLuminance(u, -.14)), f.type) { case "mouseover": s(c); break; case "mouseout": s(u); break; case "mousedown": s(d); break; case "mouseup": s(c); break; case "focus": var b = o.querySelector("button.confirm"), g = o.querySelector("button.cancel"); m ? g.style.boxShadow = "none" : b.style.boxShadow = "none"; break; case "click": var w = o === p, C = r.isDescendant(o, p); if (!w && !C && y && !n.allowOutsideClick) break; m && h && y ? l(o, n) : h && y || v ? i(o, n) : r.isDescendant(o, p) && "BUTTON" === p.tagName && sweetAlert.close() } }, l = function (e, t) { var n = !0; r.hasClass(e, "show-input") && (n = e.querySelector("input").value, n || (n = "")), t.doneFunction(n), t.closeOnConfirm && sweetAlert.close(), t.showLoaderOnConfirm && sweetAlert.disableButtons() }, i = function (e, t) { var n = String(t.doneFunction).replace(/\s/g, ""), o = "function(" === n.substring(0, 9) && ")" !== n.substring(9, 10); o && t.doneFunction(!1), t.closeOnCancel && sweetAlert.close() }; o["default"] = { handleButton: s, handleConfirm: l, handleCancel: i }, n.exports = o["default"] }, { "./handle-dom": 4, "./handle-swal-dom": 6, "./utils": 9 }], 4: [function (n, o, a) { Object.defineProperty(a, "__esModule", { value: !0 }); var r = function (e, t) { return new RegExp(" " + t + " ").test(" " + e.className + " ") }, s = function (e, t) { r(e, t) || (e.className += " " + t) }, l = function (e, t) { var n = " " + e.className.replace(/[\t\r\n]/g, " ") + " "; if (r(e, t)) { for (; n.indexOf(" " + t + " ") >= 0;) n = n.replace(" " + t + " ", " "); e.className = n.replace(/^\s+|\s+$/g, "") } }, i = function (e) { var n = t.createElement("div"); return n.appendChild(t.createTextNode(e)), n.innerHTML }, u = function (e) { e.style.opacity = "", e.style.display = "block" }, c = function (e) { if (e && !e.length) return u(e); for (var t = 0; t < e.length; ++t) u(e[t]) }, d = function (e) { e.style.opacity = "", e.style.display = "none" }, f = function (e) { if (e && !e.length) return d(e); for (var t = 0; t < e.length; ++t) d(e[t]) }, p = function (e, t) { for (var n = t.parentNode; null !== n;) { if (n === e) return !0; n = n.parentNode } return !1 }, m = function (e) { e.style.left = "-9999px", e.style.display = "block"; var t, n = e.clientHeight; return t = "undefined" != typeof getComputedStyle ? parseInt(getComputedStyle(e).getPropertyValue("padding-top"), 10) : parseInt(e.currentStyle.padding), e.style.left = "", e.style.display = "none", "-" + parseInt((n + t) / 2) + "px" }, v = function (e, t) { if (+e.style.opacity < 1) { t = t || 16, e.style.opacity = 0, e.style.display = "block"; var n = +new Date, o = function (e) { function t() { return e.apply(this, arguments) } return t.toString = function () { return e.toString() }, t }(function () { e.style.opacity = +e.style.opacity + (new Date - n) / 100, n = +new Date, +e.style.opacity < 1 && setTimeout(o, t) }); o() } e.style.display = "block" }, y = function (e, t) { t = t || 16, e.style.opacity = 1; var n = +new Date, o = function (e) { function t() { return e.apply(this, arguments) } return t.toString = function () { return e.toString() }, t }(function () { e.style.opacity = +e.style.opacity - (new Date - n) / 100, n = +new Date, +e.style.opacity > 0 ? setTimeout(o, t) : e.style.display = "none" }); o() }, h = function (n) { if ("function" == typeof MouseEvent) { var o = new MouseEvent("click", { view: e, bubbles: !1, cancelable: !0 }); n.dispatchEvent(o) } else if (t.createEvent) { var a = t.createEvent("MouseEvents"); a.initEvent("click", !1, !1), n.dispatchEvent(a) } else t.createEventObject ? n.fireEvent("onclick") : "function" == typeof n.onclick && n.onclick() }, b = function (t) { "function" == typeof t.stopPropagation ? (t.stopPropagation(), t.preventDefault()) : e.event && e.event.hasOwnProperty("cancelBubble") && (e.event.cancelBubble = !0) }; a.hasClass = r, a.addClass = s, a.removeClass = l, a.escapeHtml = i, a._show = u, a.show = c, a._hide = d, a.hide = f, a.isDescendant = p, a.getTopMargin = m, a.fadeIn = v, a.fadeOut = y, a.fireClick = h, a.stopEventPropagation = b }, {}], 5: [function (t, o, a) { Object.defineProperty(a, "__esModule", { value: !0 }); var r = t("./handle-dom"), s = t("./handle-swal-dom"), l = function (t, o, a) { var l = t || e.event, i = l.keyCode || l.which, u = a.querySelector("button.confirm"), c = a.querySelector("button.cancel"), d = a.querySelectorAll("button[tabindex]"); if (-1 !== [9, 13, 32, 27].indexOf(i)) { for (var f = l.target || l.srcElement, p = -1, m = 0; m < d.length; m++) if (f === d[m]) { p = m; break } 9 === i ? (f = -1 === p ? u : p === d.length - 1 ? d[0] : d[p + 1], r.stopEventPropagation(l), f.focus(), o.confirmButtonColor && s.setFocusStyle(f, o.confirmButtonColor)) : 13 === i ? ("INPUT" === f.tagName && (f = u, u.focus()), f = -1 === p ? u : n) : 27 === i && o.allowEscapeKey === !0 ? (f = c, r.fireClick(f, l)) : f = n } }; a["default"] = l, o.exports = a["default"] }, { "./handle-dom": 4, "./handle-swal-dom": 6 }], 6: [function (n, o, a) { var r = function (e) { return e && e.__esModule ? e : { "default": e } }; Object.defineProperty(a, "__esModule", { value: !0 }); var s = n("./utils"), l = n("./handle-dom"), i = n("./default-params"), u = r(i), c = n("./injected-html"), d = r(c), f = ".sweet-alert", p = ".sweet-overlay", m = function () { var e = t.createElement("div"); for (e.innerHTML = d["default"]; e.firstChild;) t.body.appendChild(e.firstChild) }, v = function (e) { function t() { return e.apply(this, arguments) } return t.toString = function () { return e.toString() }, t }(function () { var e = t.querySelector(f); return e || (m(), e = v()), e }), y = function () { var e = v(); return e ? e.querySelector("input") : void 0 }, h = function () { return t.querySelector(p) }, b = function (e, t) { var n = s.hexToRgb(t); e.style.boxShadow = "0 0 2px rgba(" + n + ", 0.8), inset 0 0 0 1px rgba(0, 0, 0, 0.05)" }, g = function (n) { var o = v(); l.fadeIn(h(), 10), l.show(o), l.addClass(o, "showSweetAlert"), l.removeClass(o, "hideSweetAlert"), e.previousActiveElement = t.activeElement; var a = o.querySelector("button.confirm"); a.focus(), setTimeout(function () { l.addClass(o, "visible") }, 500); var r = o.getAttribute("data-timer"); if ("null" !== r && "" !== r) { var s = n; o.timeout = setTimeout(function () { var e = (s || null) && "true" === o.getAttribute("data-has-done-function"); e ? s(null) : sweetAlert.close() }, r) } }, w = function () { var e = v(), t = y(); l.removeClass(e, "show-input"), t.value = u["default"].inputValue, t.setAttribute("type", u["default"].inputType), t.setAttribute("placeholder", u["default"].inputPlaceholder), C() }, C = function (e) { if (e && 13 === e.keyCode) return !1; var t = v(), n = t.querySelector(".sa-input-error"); l.removeClass(n, "show"); var o = t.querySelector(".sa-error-container"); l.removeClass(o, "show") }, S = function () { var e = v(); e.style.marginTop = l.getTopMargin(v()) }; a.sweetAlertInitialize = m, a.getModal = v, a.getOverlay = h, a.getInput = y, a.setFocusStyle = b, a.openModal = g, a.resetInput = w, a.resetInputError = C, a.fixVerticalPosition = S }, { "./default-params": 2, "./handle-dom": 4, "./injected-html": 7, "./utils": 9 }], 7: [function (e, t, n) { Object.defineProperty(n, "__esModule", { value: !0 }); var o = '<div class="sweet-overlay" tabIndex="-1"></div><div class="sweet-alert"><div class="sa-icon sa-error">\n      <span class="sa-x-mark">\n        <span class="sa-line sa-left"></span>\n        <span class="sa-line sa-right"></span>\n      </span>\n    </div><div class="sa-icon sa-warning">\n      <span class="sa-body"></span>\n      <span class="sa-dot"></span>\n    </div><div class="sa-icon sa-info"></div><div class="sa-icon sa-success">\n      <span class="sa-line sa-tip"></span>\n      <span class="sa-line sa-long"></span>\n\n      <div class="sa-placeholder"></div>\n      <div class="sa-fix"></div>\n    </div><div class="sa-icon sa-custom"></div><h2>Title</h2>\n    <p>Text</p>\n    <fieldset>\n      <input type="text" tabIndex="3" />\n      <div class="sa-input-error"></div>\n    </fieldset><div class="sa-error-container">\n      <div class="icon">!</div>\n      <p>Not valid!</p>\n    </div><div class="sa-button-container">\n      <button class="cancel" tabIndex="2">Cancel</button>\n      <div class="sa-confirm-button-container">\n        <button class="confirm" tabIndex="1">OK</button><div class="la-ball-fall">\n          <div></div>\n          <div></div>\n          <div></div>\n        </div>\n      </div>\n    </div></div>'; n["default"] = o, t.exports = n["default"] }, {}], 8: [function (e, t, o) { Object.defineProperty(o, "__esModule", { value: !0 }); var a = e("./utils"), r = e("./handle-swal-dom"), s = e("./handle-dom"), l = ["error", "warning", "info", "success", "input", "prompt"], i = function (e) { var t = r.getModal(), o = t.querySelector("h2"), i = t.querySelector("p"), u = t.querySelector("button.cancel"), c = t.querySelector("button.confirm"); if (o.innerHTML = e.html ? e.title : s.escapeHtml(e.title).split("\n").join("<br>"), i.innerHTML = e.html ? e.text : s.escapeHtml(e.text || "").split("\n").join("<br>"), e.text && s.show(i), e.customClass) s.addClass(t, e.customClass), t.setAttribute("data-custom-class", e.customClass); else { var d = t.getAttribute("data-custom-class"); s.removeClass(t, d), t.setAttribute("data-custom-class", "") } if (s.hide(t.querySelectorAll(".sa-icon")), e.type && !a.isIE8()) { var f = function () { for (var o = !1, a = 0; a < l.length; a++) if (e.type === l[a]) { o = !0; break } if (!o) return logStr("Unknown alert type: " + e.type), { v: !1 }; var i = ["success", "error", "warning", "info"], u = n; -1 !== i.indexOf(e.type) && (u = t.querySelector(".sa-icon.sa-" + e.type), s.show(u)); var c = r.getInput(); switch (e.type) { case "success": s.addClass(u, "animate"), s.addClass(u.querySelector(".sa-tip"), "animateSuccessTip"), s.addClass(u.querySelector(".sa-long"), "animateSuccessLong"); break; case "error": s.addClass(u, "animateErrorIcon"), s.addClass(u.querySelector(".sa-x-mark"), "animateXMark"); break; case "warning": s.addClass(u, "pulseWarning"), s.addClass(u.querySelector(".sa-body"), "pulseWarningIns"), s.addClass(u.querySelector(".sa-dot"), "pulseWarningIns"); break; case "input": case "prompt": c.setAttribute("type", e.inputType), c.value = e.inputValue, c.setAttribute("placeholder", e.inputPlaceholder), s.addClass(t, "show-input"), setTimeout(function () { c.focus(), c.addEventListener("keyup", swal.resetInputError) }, 400) } }(); if ("object" == typeof f) return f.v } if (e.imageUrl) { var p = t.querySelector(".sa-icon.sa-custom"); p.style.backgroundImage = "url(" + e.imageUrl + ")", s.show(p); var m = 80, v = 80; if (e.imageSize) { var y = e.imageSize.toString().split("x"), h = y[0], b = y[1]; h && b ? (m = h, v = b) : logStr("Parameter imageSize expects value with format WIDTHxHEIGHT, got " + e.imageSize) } p.setAttribute("style", p.getAttribute("style") + "width:" + m + "px; height:" + v + "px") } t.setAttribute("data-has-cancel-button", e.showCancelButton), e.showCancelButton ? u.style.display = "inline-block" : s.hide(u), t.setAttribute("data-has-confirm-button", e.showConfirmButton), e.showConfirmButton ? c.style.display = "inline-block" : s.hide(c), e.cancelButtonText && (u.innerHTML = s.escapeHtml(e.cancelButtonText)), e.confirmButtonText && (c.innerHTML = s.escapeHtml(e.confirmButtonText)), e.confirmButtonColor && (c.style.backgroundColor = e.confirmButtonColor, c.style.borderLeftColor = e.confirmLoadingButtonColor, c.style.borderRightColor = e.confirmLoadingButtonColor, r.setFocusStyle(c, e.confirmButtonColor)), t.setAttribute("data-allow-outside-click", e.allowOutsideClick); var g = e.doneFunction ? !0 : !1; t.setAttribute("data-has-done-function", g), e.animation ? "string" == typeof e.animation ? t.setAttribute("data-animation", e.animation) : t.setAttribute("data-animation", "pop") : t.setAttribute("data-animation", "none"), t.setAttribute("data-timer", e.timer) }; o["default"] = i, t.exports = o["default"] }, { "./handle-dom": 4, "./handle-swal-dom": 6, "./utils": 9 }], 9: [function (t, n, o) { Object.defineProperty(o, "__esModule", { value: !0 }); var a = function (e, t) { for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]); return e }, r = function (e) { var t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e); return t ? parseInt(t[1], 16) + ", " + parseInt(t[2], 16) + ", " + parseInt(t[3], 16) : null }, s = function () { return e.attachEvent && !e.addEventListener }, l = function (t) { e.console && e.console.log("SweetAlert: " + t) }, i = function (e, t) { e = String(e).replace(/[^0-9a-f]/gi, ""), e.length < 6 && (e = e[0] + e[0] + e[1] + e[1] + e[2] + e[2]), t = t || 0; var n, o, a = "#"; for (o = 0; 3 > o; o++) n = parseInt(e.substr(2 * o, 2), 16), n = Math.round(Math.min(Math.max(0, n + n * t), 255)).toString(16), a += ("00" + n).substr(n.length); return a }; o.extend = a, o.hexToRgb = r, o.isIE8 = s, o.logStr = l, o.colorLuminance = i }, {}] }, {}, [1]), "function" == typeof define && define.amd ? define(function () { return sweetAlert }) : "undefined" != typeof module && module.exports && (module.exports = sweetAlert) }(window, document);

/**
 * jQuery DFP v2.4.2
 * http://github.com/coop182/jquery.dfp.js
 *
 * Copyright 2016 Matt Cooper
 * Released under the MIT license
 */
!function (a, b) { "use strict"; !function (b) { "function" == typeof define && define.amd ? define(["jquery"], b) : b("object" == typeof exports ? require("jquery") : a.jQuery || a.Zepto) }(function (c) { var d = this || {}, e = "", f = 0, g = 0, h = 0, i = ".adunit", j = !1, k = !1, l = "googleAdUnit", m = function (a, b, g) { var i; f = 0, h = 0, e = a, i = c(b), d.shouldCheckForAdBlockers = function () { return g ? "function" == typeof g.afterAdBlocked : !1 }, u(g, i).then(function () { g = n(g), d.dfpOptions = g, c(function () { o(g, i), p(g, i) }) }) }, n = function (d) { var e = { setTargeting: {}, setCategoryExclusion: "", setLocation: "", enableSingleRequest: !0, collapseEmptyDivs: "original", refreshExisting: !0, disablePublisherConsole: !1, disableInitialLoad: !1, setCentering: !1, noFetch: !1, namespace: b, sizeMapping: {} }; if ("undefined" == typeof d.setUrlTargeting || d.setUrlTargeting) { var f = q(d.url); c.extend(!0, e.setTargeting, { UrlHost: f.Host, UrlPath: f.Path, UrlQuery: f.Query }) } return c.extend(!0, e, d), e.googletag && a.googletag.cmd.push(function () { c.extend(!0, a.googletag, e.googletag) }), e }, o = function (b, g) { var i = a.googletag; g.each(function () { var a = c(this); f++; var d = s(a, b), g = r(a, d), h = t(a); a.data("existingContent", a.html()), a.html("").addClass("display-none"), i.cmd.push(function () { var f, j = a.data(l); if (j) f = j; else { var k; k = "" === e ? d : "/" + e + "/" + d, a.data("outofpage") ? f = i.defineOutOfPageSlot(k, g) : (f = i.defineSlot(k, h, g), a.data("companion") && (f = f.addService(i.companionAds()))), f = f.addService(i.pubads()) } var m = a.data("targeting"); m && c.each(m, function (a, b) { f.setTargeting(a, b) }); var n = a.data("exclusions"); if (n) { var o, p = n.split(","); c.each(p, function (a, b) { o = c.trim(b), o.length > 0 && f.setCategoryExclusion(o) }) } var q = a.data("size-mapping"); if (q && b.sizeMapping[q]) { var r = i.sizeMapping(); c.each(b.sizeMapping[q], function (a, b) { r.addSize(b.browser, b.ad_sizes) }), f.defineSizeMapping(r.build()) } a.data(l, f), "function" == typeof b.beforeEachAdLoaded && b.beforeEachAdLoaded.call(this, a) }) }), i.cmd.push(function () { var a = i.pubads(); b.enableSingleRequest && a.enableSingleRequest(), c.each(b.setTargeting, function (b, c) { a.setTargeting(b, c) }); var e = b.setLocation; if ("object" == typeof e && ("number" == typeof e.latitude && "number" == typeof e.longitude && "number" == typeof e.precision ? a.setLocation(e.latitude, e.longitude, e.precision) : "number" == typeof e.latitude && "number" == typeof e.longitude && a.setLocation(e.latitude, e.longitude)), b.setCategoryExclusion.length > 0) { var j, k = b.setCategoryExclusion.split(","); c.each(k, function (b, d) { j = c.trim(d), j.length > 0 && a.setCategoryExclusion(j) }) } b.collapseEmptyDivs && a.collapseEmptyDivs(), b.disablePublisherConsole && a.disablePublisherConsole(), b.companionAds && (i.companionAds().setRefreshUnfilledSlots(!0), b.disableInitialLoad || a.enableVideoAds()), b.disableInitialLoad && a.disableInitialLoad(), b.noFetch && a.noFetch(), b.setCentering && a.setCentering(!0), a.addEventListener("slotRenderEnded", function (a) { h++; var d = c("#" + a.slot.getSlotId().getDomId()), e = a.isEmpty ? "none" : "block", i = d.data("existingContent"); "none" === e && c.trim(i).length > 0 && "original" === b.collapseEmptyDivs && (d.show().html(i), e = "block display-original"), d.removeClass("display-none").addClass("display-" + e), "function" == typeof b.afterEachAdLoaded && b.afterEachAdLoaded.call(this, d, a), "function" == typeof b.afterAllAdsLoaded && h === f && b.afterAllAdsLoaded.call(this, g) }), d.shouldCheckForAdBlockers() && !i._adBlocked_ && setTimeout(function () { var e = a.getSlots ? a.getSlots() : []; e.length > 0 && c.get(e[0].getContentUrl()).always(function (a) { 200 !== a.status && c.each(e, function () { var a = c("#" + this.getSlotId().getDomId()); b.afterAdBlocked.call(d, a, this) }) }) }, 0), i.enableServices() }) }, p = function (b, e) { var f = a.googletag; if (d.shouldCheckForAdBlockers() && !f._adBlocked_ && f.getVersion) { var g = "//partner.googleadservices.com/gpt/pubads_impl_" + f.getVersion() + ".js"; c.getScript(g).always(function (a) { a && "error" === a.statusText && c.each(e, function () { b.afterAdBlocked.call(d, c(this)) }) }) } e.each(function () { var a = c(this), e = a.data(l); f._adBlocked_ && d.shouldCheckForAdBlockers() && b.afterAdBlocked.call(d, a), f.cmd.push(b.refreshExisting && e && a.hasClass("display-block") ? function () { f.pubads().refresh([e]) } : function () { f.display(a.attr("id")) }) }) }, q = function (b) { var c = (b || a.location.toString()).match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/), d = c[4] || "", e = (c[5] || "").replace(/(.)\/$/, "$1"), f = c[7] || "", g = f.replace(/\=/gi, ":").split("&"); return { Host: d, Path: e, Query: g } }, r = function (a, b) { return g++, a.attr("id") || a.attr("id", b.replace(/[^A-z0-9]/g, "_") + "-auto-gen-id-" + g).attr("id") }, s = function (a, b) { var c = a.data("adunit") || b.namespace || a.attr("id") || ""; return "function" == typeof b.alterAdUnitName && (c = b.alterAdUnitName.call(this, c, a)), c }, t = function (a) { var b = [], d = a.data("dimensions"); if (d) { var e = d.split(","); c.each(e, function (a, c) { var d = c.split("x"); b.push([parseInt(d[0], 10), parseInt(d[1], 10)]) }) } else b.push([a.width(), a.height()]); return b }, u = function (b, e) { function f() { d.shouldCheckForAdBlockers() && c.each(e, function () { b.afterAdBlocked.call(d, c(this)) }) } if (k = k || c('script[src*="googletagservices.com/tag/js/gpt.js"]').length) return j && f(), c.Deferred().resolve(); var g = c.Deferred(); a.googletag = a.googletag || {}, a.googletag.cmd = a.googletag.cmd || []; var h = document.createElement("script"); h.async = !0, h.type = "text/javascript", h.onerror = function () { v(), g.resolve(), j = !0, f() }, h.onload = function () { googletag._loadStarted_ || (googletag._adBlocked_ = !0, f()), g.resolve() }; var i = "https:" === document.location.protocol; h.src = (i ? "https:" : "http:") + "//www.googletagservices.com/tag/js/gpt.js"; var l = document.getElementsByTagName("script")[0]; return l.parentNode.insertBefore(h, l), "none" === h.style.display && v(), g }, v = function () { var b = a.googletag, e = b.cmd, f = function (a, c, d, e) { return b.ads.push(d), b.ads[d] = { renderEnded: function () { }, addService: function () { return this } }, b.ads[d] }; b = { cmd: { push: function (a) { a.call(d) } }, ads: [], pubads: function () { return this }, noFetch: function () { return this }, disableInitialLoad: function () { return this }, disablePublisherConsole: function () { return this }, enableSingleRequest: function () { return this }, setTargeting: function () { return this }, collapseEmptyDivs: function () { return this }, enableServices: function () { return this }, defineSlot: function (a, b, c) { return f(a, b, c, !1) }, defineOutOfPageSlot: function (a, b) { return f(a, [], b, !0) }, display: function (a) { return b.ads[a].renderEnded.call(d), this } }, c.each(e, function (a, c) { b.cmd.push(c) }) }; c.dfp = c.fn.dfp = function (a, c) { c = c || {}, a === b && (a = e), "object" == typeof a && (c = a, a = c.dfpID || e); var d = this; return "function" == typeof this && (d = i), m(a, d, c), this } }) }(window);

// Settings 
var serviceLoginResource = "/templatesresponsive/services/authenticationservice.asmx/signin";
var serviceLogoutResource = "/templatesresponsive/services/authenticationservice.asmx/signout";

// On DOM Ready
$(document).ready(function () {
	// Validate user is logged In first
    if ($('#hfToken').length > 0)
    {
        var areWeOnMobileLoggedIn = $('#mobile-menu-toggle').is(":visible");
        if (areWeOnMobileLoggedIn)
        {
            $('#USBCbutton').removeClass('no-children');
            $('#USBCbutton').addClass('my-usbc');
            $(".my-usbc-group").addClass("open");
            $('#USBCbutton ').attr('href', '#');
            $('#USBCbutton ').text('My USBC');
        }
    }
    
    // News Details search input search
    // by doing JS we avoid the postback
    $('.news-search #btnSearch').click(function () {
        var searchUrl = "/news/?search=" + $('.news-search #txtKeywords').val();
        window.location.href = searchUrl;
    });

    $('.search-button').click(function () {
        var searchUrl = "/search/?searchtext=" + $('.search-keywords').val();
        window.location.href = searchUrl;
    });

    $('.news-search #txtKeywords').keypress(function (e) {
        var key = e.which;
        // if the enter key code
        if (key == 13) {
            $('.news-search #btnSearch').click();
            return false;
        }
    });

    $('#ddlApprovedBallList').change(function () {
        var brandname = $(this).val();
        GetApprovedBalls(brandname);
    });

    $('.form-login-page #login-password2').keypress(function (e) {
        var key = e.which;
        // if the enter key code
        if (key == 13) {
            $('.form-login-page #btn-login-submit').click();
            return false;
        }
    });

    // Set the width of the screen on a hidden control in case you need it for responsive design on back-end
    if ($('#hScreenWidth').length > 0) {
        $('#hScreenWidth').val($(window).width());
    }

    // Enable search on top menu
    $('.top-search #btnSearch').click(function () {
        var searchUrl = "/search/?searchtext=" + $('.top-search #txtKeywords').val();
        window.location.href = searchUrl;
    });

    // Enable Enter key on search at the top eyebrow
    $('.top-search #txtKeywords').keypress(function (e) {
        var key = e.which;
        // if the enter key code
        if (key == 13) {
            $('.top-search #btnSearch').click();
            return false;
        }
    });

    // Enable Enter key on eyebrow login fields
    $('.login-wrapper .login__field').keypress(function (e) {
        var key = e.which;
        // if the enter key code
        if (key == 13) {
            $('.login-wrapper #btn-login-submit').click();
            return false;
        }
    });

    // Slick event to change color of ribbon and stripes
    if ($('.slide--foreground').length > 1) {
        // On before slide change
        $('.slider--foreground').on('afterChange', function (event, slick, currentSlide, nextSlide) {
            var $slides = $('.slider--foreground').slick("getSlick").$slides;
            var slide = $slides.eq(currentSlide);

            var ribbonColor = "ribbon " + slide.data("ribboncolor");
            var stripesColor = "stripes " + slide.data("stripescolor");

            //$('#divRibbonColor').removeAttr("class");
            //$('#divStripesColor').removeAttr("class");

            // Add new classes
            $('#divRibbonColor').attr("class", ribbonColor);
            $('#divStripesColor').attr("class", stripesColor);
        }); 
    }

    $(".my-usbc").click(function () {
        $(".nav-level-1").addClass("left");
        $(".nav-level-2").addClass("open");
        $(".my-usbc-group").addClass("open");
    });

    $(".exit-my-usbc").click(function () {
        $(".nav-level-1").removeClass("left");
        $(".nav-level-2").removeClass("open");
        $(".my-usbc-group").removeClass("open");
    });

    // Adding a custom close button for tablets menu
    var isDesktop = $('body').hasClass('desktop');
    var isMobile = $('#mobile-menu-toggle').is(":visible");

    // If TABLET
    if (!isDesktop && !isMobile) {
        // Show the X
        $('.close-button').show();
        // Event handler to close the mega menu
        $('.close-button').on('click', function (event) {
            $('.nav-level-1').trigger('click');
        });

        $(document).on('touchend', function (event) {
            // Close the menu
            if (!$(event.target).closest('.nav-level-1').length && !$(event.target).closest('.nav-level-3').length) {
                // here we need to fire this when click again
                if ($('.nav-level-3').is(":visible")) {
                    window.frontendApp.menu.setCurrentPath('');
                }
            }

            // Close Search box
            if (!$(event.target).closest('.search__toggle').length && !$(event.target).closest('#btnSearch').length) {
                $(".search__toggle").removeClass("open");
                $(".search__input--wrapper").removeClass("open");
                $("input.search__input").blur();
                $(".search-container").removeClass("open");
                $(".search__button").removeClass("open");
                $("body").removeClass("search-open");
            }
        });

        $('.footer-col__link').on('touchstart', function (event) {
            $('.footer-col__link').css("color", "#FFFFFF");
        });

        $('.footer-col__link').on('touchend', function (event) {
            $('.footer-col__link').css("color", "#FFFFFF");
        });
    }

    // If we are in STEP 02 on activate let's show a modal window for all users
    if ($('.panel-create-user-step02').length > 0 && $('.alert-danger').length <= 0)
        if ($('.panel-create-user-step02 #emailAddress').val() != "") {

            swal({
                title: "",
                text: $(".panel-create-user-step02 #modalSmartInfoMessage").html(),
                html: true,
                confirmButtonText: "Close"
            });
        }

    // Disable submit button
    if ($('.btn-overlay').length > 0)
        $('.btn-overlay').prop("disabled", false);

    $(window).on('beforeunload', function () {
        if ($('.btn-overlay').length > 0) {
            $('.btn-overlay').prop("value", "Processing...");
            $('.btn-overlay').prop("disabled", true);
        }
    });

    // DFP Google Ads
    var areWeOnMobile = $('#mobile-menu-toggle').is(":visible");

    // DFP Ad - Top
    $('.ad-leaderboard').dfp({
        dfpID: '1065174',
        sizeMapping: {
            'usbc_ad_sizes': [
                { browser: [0, 0], ad_sizes: [[970, 90]] },
                { browser: [320, 200], ad_sizes: [320, 50] },
                { browser: [640, 200], ad_sizes: [[320, 50], [320, 100], [320, 150]] },
                { browser: [768, 200], ad_sizes: [728, 90] },
                { browser: [980, 200], ad_sizes: [728, 90] },
                { browser: [1000, 200], ad_sizes: [[970, 90]] },
                { browser: [1280, 200], ad_sizes: [[970, 90]] }
            ],
        },
        // Callback which is run after the render of each ad.
        afterEachAdLoaded: function (adUnit) {
            if ($(adUnit).hasClass("ad-leaderboard") && areWeOnMobile == false) {
                // Do something after each ad is loaded.
                if ($(adUnit).hasClass('display-none')) {
                    console.log("Top Ad was not found in DFP");
                    $('.page-stripes .stripes div:first-child').attr('style', 'left: -1094px !important');
                    $('.page-stripes .stripes div:last-child').attr('style', 'left: -1035px !important');
                } else {
                    
                }
            }
        }
    });

    // DFP Ad - Bottom
    $('.ad-bottom').dfp({
        dfpID: '1065174',
        sizeMapping: {
            'usbc_ad_sizes': [
                { browser: [0, 0], ad_sizes: [[970, 90]] },
                { browser: [320, 200], ad_sizes: [320, 50] },
                { browser: [640, 200], ad_sizes: [[320, 50], [320, 100], [320, 150]] },
                { browser: [768, 200], ad_sizes: [728, 90] },
                { browser: [980, 200], ad_sizes: [728, 90] },
                { browser: [1000, 200], ad_sizes: [[970, 90]] },
                { browser: [1280, 200], ad_sizes: [[970, 90]] }
            ],
        },
        // Callback which is run after the render of each ad.
        afterEachAdLoaded: function (adUnit) {
            if ($(adUnit).hasClass("ad-bottom") && areWeOnMobile == false) {
                // Do something after each ad is loaded.
                if ($(adUnit).hasClass('display-none')) {
                    //console.log("Bottom Ad was not found in DFP");
                    //$('.scroll--header.page-stripes').css('top', '-145px');
                } else {
                    
                }
            }
        }
    });

    $('.ad-right-siderbar').dfp({
        dfpID: '1065174',
        setCentering: true,
        sizeMapping: {
            'usbc_ad_sizes': [
                { browser: [0, 0], ad_sizes: [300, 250] },
                { browser: [320, 200], ad_sizes: [300, 250] },
                { browser: [640, 200], ad_sizes: [300, 250] },
                { browser: [768, 200], ad_sizes: [300, 250] },
                { browser: [980, 200], ad_sizes: [300, 250] },
                { browser: [1000, 200], ad_sizes: [300, 250] },
                { browser: [1280, 200], ad_sizes: [[300, 250]] }
            ],
        },
        // Callback which is run after the render of each ad.
        afterEachAdLoaded: function (adUnit) {
            if ($(adUnit).hasClass("ad-right-siderbar") && areWeOnMobile == false)
            {
                // Do something after each ad is loaded.
                if ($(adUnit).hasClass('display-none')) {
                    //console.log("Right Ad was not found in DFP");
                } else {
                    $contents = $('.ad-right-siderbar iframe:first').contents();
                    $contents.find('img').width('100%').height('auto');
                    $('.ad-right-siderbar iframe').attr('width', '100%').attr('height', '250');
                }
            }
        }
    });

    $('.ad-right-tournament').dfp({
        dfpID: '1065174',
        setCentering: true,
        sizeMapping: {
            'usbc_ad_sizes': [
                { browser: [0, 0], ad_sizes: [[240, 120]] },
                { browser: [320, 200], ad_sizes: [[240, 120]] },
                { browser: [640, 200], ad_sizes: [[240, 120]] },
                { browser: [768, 200], ad_sizes: [[240, 120]] },
                { browser: [980, 200], ad_sizes: [[240, 120]] },
                { browser: [1000, 200], ad_sizes: [[240, 120]] }
            ],
        },
        // Callback which is run after the render of each ad.
        afterEachAdLoaded: function (adUnit) {
            if ($(adUnit).hasClass("ad-right-tournament") && areWeOnMobile == false) {
                // Do something after each ad is loaded.
                if ($(adUnit).hasClass('display-none')) {
                    //console.log("Right Ad was not found in DFP");
                } else {
                    $(".ad-right-tournament").each(function (index) {
                        $contents = $(this).find("iframe:first").contents(); 
                        $contents.find('img').width('100%').height('150');
                        $('.ad-right-tournament iframe').attr('width', '100%').attr('height', '150');
                    });

                  
                }
            }
        }
    });

    if (areWeOnMobile) {
        $($('.ads-desktop-and-tablet-only').detach()).appendTo(".ads-mobile-only");
    }

     // Fix the bar angles when no ads found
     //console.log($('.ad-leaderboard').attr('class'));
    //if ($(".leaderboard div.ad-leaderboard").length <= 0){
      //  console.log('No ad found');
        //$('.scroll--header.page-stripes').css('top', '-145px');
    //}
    
});


// Code for Login/activate section of Header
function Login() {
    $('.topLoginveil').show();
    var $this = $(this);
    if ($this.attr('disable') != true) {
        var usbc_u = $('#login-username').val(),
            usbc_p = $('#login-password').val();
        if (usbc_u == '') {
            swal({
                title: "Validation",
                text: "Username cannot be blank<br><br>",
                html: true,
                confirmButtonText: "Close",
                type: "warning"
            });
            //alert("Username cannot be blank");
            $('.topLoginveil').hide();
            resp = false;
            return true;
        }
        else {
            resp = true;
        }

        if (usbc_p == '') {
            swal({
                title: "Validation",
                text: "Password cannot be blank<br><br>",
                html: true,
                confirmButtonText: "Close",
                type: "warning"
            });

            $('.topLoginveil').hide();
            resp = false;
            return true;

        }
        else {
            resp = true;
        }


        if (resp = true) {
            $this.attr('disable', true).text($this.data('loading-text'));
            var encodedPass = btoa(usbc_p);
            $.ajax({
                url: serviceLoginResource,
                type: 'post',
                data: "{ 'usbcu': '" + usbc_u + "', 'usbcp': '" + encodedPass + "' }",
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            }).done(function (response) {
                var data = response.d;
                if (data.Status === 'Valid') {
                    $('#logincontrol').hide();
                    //$('#logged-in').show();
                    $('.topLoginveil').hide();
                    window.location.reload();
                }
                else {
                    if (data.Status === 'changepassword') {
                        document.location = '/changepassword';
                    } else {
                        $('.topLoginveil').hide();
                        $this.text('Sign In').attr('disable', false);
                        // Let's show the message coming from backend
                        if (data.Message != "") {
                            swal({
                                title: "Validation",
                                text: data.Message + "<br><br>",
                                html: true,
                                confirmButtonText: "Close",
                                type: "warning"
                            });
                        }
                        else {
                            swal({
                                title: "Validation",
                                text: "An Exception occurs. Please try again.<br><br>",
                                html: true,
                                confirmButtonText: "Close",
                                type: "warning"
                            });
                        }
                    }
                }
            }).fail(function () {
                $('.topLoginveil').hide();
                $this.text('Sign In').attr('disable', false);
                swal({
                    title: "Validation",
                    text: "An Exception occurs. Please try again.<br><br>",
                    html: true,
                    confirmButtonText: "Close",
                    type: "warning"
                });
            });

        }
    }
}

// Login users from /Login page
function LoginSign() {
    var resp = true;
    //e.preventDefault();
    $('.topLoginveil').show();
    var $this = $(this);
    if ($this.attr('disable') != true) {
        var usbc_u = $('#login-username2').val(),
            usbc_p = $('#login-password2').val();

        if (usbc_u == '') {
            swal({
                title: "Validation",
                text: "Username cannot be blank<br><br>",
                html: true,
                confirmButtonText: "Close",
                type: "warning"
            });
            $('.topLoginveil').hide();
            resp = false;
            return false;

        } else {
            resp = true;
        }

        if (usbc_p == '') {
            swal({
                title: "Validation",
                text: "Password cannot be blank<br><br>",
                html: true,
                confirmButtonText: "Close",
                type: "warning"
            });
            $('.topLoginveil').hide();
            resp = false;
            return false;

        } else {
            resp = true;
        }


        if (resp = true) {
            $this.attr('disable', true).text($this.data('loading-text'));
            var encodedPass = btoa(usbc_p);
            //console.log(encodedPass);
            $.ajax({
                url: serviceLoginResource,
                type: 'post',
                data: "{ 'usbcu': '" + usbc_u + "', 'usbcp': '" + encodedPass + "' }",
                dataType: 'json',
                contentType: 'application/json; charset=utf-8'
            }).done(function (response) {
            	//console.log(response);
                var data = response.d;
                if (data.Status === 'Valid') {
                    $('#logincontrol').hide();
                    $('#logged-in').show();
                    $('.topLoginveil').hide();
                    $('#USBCbutton').removeClass('no-children');
                    $('#USBCbutton').addClass('my-usbc');
                    $(".my-usbc-group").addClass("open");
                    $('#USBCbutton ').attr('href', '#');
                    $('#USBCbutton ').text('My USBC');
                    //location.href = "/";
                    window.location.reload();
                }
                else {
                    if (data.Status === 'changepassword') {
                        document.location = '/changepassword';
                    } else {
                        $('.topLoginveil').hide();
                        $this.text('Sign In').attr('disable', false);
                        // Let's show the message coming from backend
                        if (data.Message != "") {
                            swal({
                                title: "Validation",
                                text: data.Message + "<br><br>",
                                html: true,
                                confirmButtonText: "Close",
                                type: "warning"
                            });
                        }
                        else {
                            swal({
                                title: "Validation",
                                text: "An Exception occurs. Please try again.<br><br>",
                                html: true,
                                confirmButtonText: "Close",
                                type: "warning"
                            });
                        }
                    }
                }
                return true;
            }).fail(function () {
                $('.topLoginveil').hide();
                $this.text('Sign In').attr('disable', false);
                swal({
                    title: "Validation",
                    text: "An Exception occurs. Please try again.<br><br>",
                    html: true,
                    confirmButtonText: "Close",
                    type: "warning"
                });
            });
        }
    }
    return true;

}

function logout() {
    $('.topLoginveil').show();
    $.ajax({
        url: serviceLogoutResource,
        type: 'post',
        data: "",
        dataType: 'json',
        contentType: 'application/json; charset=utf-8'
    }).done(function (response) {
        var d = new Date();
        var ticks = d.getTime();
        location.href = "/?" + ticks;
    });
}

function profile() {
    $('.topLoginveil').show();
    location.href = "/MyProfile";
}

function ValidateEmail(emailAddress) {
    var emailRegex = new RegExp(/^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/);
    var validformat1 = emailRegex.test(emailAddress);
    if (!validformat1) {
        return false
    }

    return true;
}

// Validate home Phone on profile template
function ClientValidate(source, arguments) {
    var propertyOne = "#" + $('.home-phone-validator').attr('propertyOne');
    var propertyTwo = "#" + $('.home-phone-validator').attr('propertyTwo');
    var propertyThree = "#" + $('.home-phone-validator').attr('propertyThree');

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length > 0) {
        if ($(propertyOne).val().length == 3 && $(propertyTwo).val().length == 3 && $(propertyThree).val().length == 4) {
            arguments.IsValid = true;
        }
        else {
            arguments.IsValid = false;
        }
    }

    // Special validation for min length of each field
    /* if ($(propertyOne).val().length == 3 && $(propertyTwo).val().length == 3 && $(propertyThree).val().length == 4) {
         arguments.IsValid = true;
     }
     else {
         arguments.IsValid = false;
     }*/
}

// Validate cell phone on profile template
function ClientValidateCellPhone(source, arguments) {
    var propertyOne = "#" + $('.cell-phone-validator').attr('propertyOne');
    var propertyTwo = "#" + $('.cell-phone-validator').attr('propertyTwo');
    var propertyThree = "#" + $('.cell-phone-validator').attr('propertyThree');

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length == 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length == 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length == 0 && $(propertyThree).val().length > 0) {
        arguments.IsValid = false;
    }

    if ($(propertyOne).val().length > 0 && $(propertyTwo).val().length > 0 && $(propertyThree).val().length > 0) {
        if ($(propertyOne).val().length == 3 && $(propertyTwo).val().length == 3 && $(propertyThree).val().length == 4) {
            arguments.IsValid = true;
        }
        else {
            arguments.IsValid = false;
        }
    }
}

function EmailsMatch(source, arguments) {
    var propertyOne = "#" + $('.email-match-validator').attr('propertyOne');
    var propertyTwo = "#" + $('.email-match-validator').attr('propertyTwo');

    if ($(propertyOne).val() === $(propertyTwo).val()) {
        arguments.IsValid = true;
    }
    else {
        arguments.IsValid = false;
    }
}

function PasswordsMatch(source, arguments) {
    var propertyOne = "#" + $('.password-match-validator').attr('propertyOne');
    var propertyTwo = "#" + $('.password-match-validator').attr('propertyTwo');
    if ($(propertyOne).val() === $(propertyTwo).val()) {
        arguments.IsValid = true;
    }
    else {
        arguments.IsValid = false;
    }
}

function isNumericKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function GetApprovedBalls(brandname) {
    $.ajax({
        type: "GET",
        url: "/approvedballlist/netballs.xml",
        dataType: "xml",
        beforeSend: function () {
            $('#response').html("<img src='/templatesresponsive/resources/img/spin-bowl.gif' />");
        },
        success: function (xml) {
            $('#approvedlist').empty();
            $('#approvedlistheader').show();
            $('#response').empty();
            var brands = $(xml).find('Brand');
            brands.sort(function (a, b) {
                return ($(a).find('BallName').text() > $(b).find('BallName').text()) ? 1 : -1;
            });
            brands.each(function () {
                if (brandname == $(this).attr('name')) {
                    var name = "<a href=\"javascript:;\" data-original-title=\"<img src='" + $(this).find('link').text() + "' />\" data-toggle=\"tooltip\" data-placement=\"right\" data-html=\"true\">" + $(this).find('BallName').text() + "</a>";
                    var date = $(this).find('DateApproved').text();
                    $('#approvedlist').append("<tr><td>" + name + "</td><td>" + date + "</td></tr>");
                }
            });
            $('#approvedlist a').tooltip({ trigger: 'hover' });
        }
    });
}
