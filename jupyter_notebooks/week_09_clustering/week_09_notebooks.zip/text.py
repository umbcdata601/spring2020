this_text="I go to the store. A car is parked. \
Many cars are parked or moving. Some are blue. \
Some are tan. They have windows. In the store, \
there are items for sale. These include such \
things as soap, detergent, magazines, and lettuce. \
You can enhance your life with these products. \
Soap can be used for bathing, be it in a bathtub \
or in a shower. My email address is myname@sc.edu. \
Apply the soap to your body and rinse. My phone \
number is 452-953-2942. Detergent is used to \
wash clothes. Place your dirty clothes \
into a washing machine and add some detergent \
as directed on the box. Your email is \
aperson@farm.com and your cell is 595-942-2424. \
Select the appropriate settings on your \
washing machine and you should be ready to \
begin. Magazines are stapled reading material \
made with glossy paper, and they cover a wide \
variety of topics, ranging from news and \
politics to business and stock market information."